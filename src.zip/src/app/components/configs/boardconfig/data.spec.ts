
export class Data {
  PlayerName :string;
  Run:string;
}
