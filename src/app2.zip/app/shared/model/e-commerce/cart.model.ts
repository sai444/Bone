import { Products } from "./product.model";

export class CartItem {
    product: Products;
    quantity: number;
}