import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as Chart from 'chart.js';


import { ChartsModule } from 'ng2-charts';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-plantline',
  templateUrl: './plantline.component.html',
  styleUrls: ['./plantline.component.scss']
})
export class PlantlineComponent implements OnInit {

  selectedQuantity;
  selectedQuantitys;
values;
values1;
values2;
values3;
values4;
values5;
values6;
values7;
values8;
values9;
values10;
values11;
values12;
values13;
values14;
values15;
values16;
values17;
values18;
values19;
values20;
values21;
values22;
values23;
values24;

tagvalues1;
tagvalues2;
tagvalues3;
tagvalues4;
tagvalues5;
tagvalues6;
tagvalues7;
tagvalues8;
tagvalues9;
tagvalues10;
tagvalues11;
tagvalues12;
tagvalues13;
tagvalues14;
tagvalues15;
tagvalues16;
tagvalues17;
tagvalues18;
tagvalues19;
tagvalues20;
tagvalues21;
tagvalues22;
tagvalues23;
tagvalues24;

optionsp : string[] = ['SKF BNG']
   options1: string[] = ["CHANNEL-5","CHANNEL-6"];
   options: string[] = [ "SGB CH5","SPC (IR) CH5", "SPC (OR) CH5"];

  @ViewChild(BaseChartDirective) chart: BaseChartDirective;
  @ViewChild(BaseChartDirective) chart1: BaseChartDirective;
  @ViewChild(BaseChartDirective) chart2: BaseChartDirective;
  @ViewChild(BaseChartDirective) chart3: BaseChartDirective;

  public label = 8;
  public a = 0;

  public tasklist;
  public tasklist1;
  public tasklist2;
  public tasklist3;
  public list = [];
  public list1 = [];
  public list2= [];
  public list3 =[];
  public list4 =[];
  public list5 =[];

  validationForm: FormGroup;


  constructor(public http: HttpClient, private fb: FormBuilder ) { }


  public lineChartData: Array<any> = [
    0, 0, 0, 0, 0, 0, 0, 0,0,0
    ];
  public lineChartData1: Array<any> = [
      0, 0, 0, 0, 0, 0, 0, 0,0 ,0
      ];
      public lineChartData2: Array<any> = [
        0, 0, 0, 0, 0, 0, 0, 0,0,0
        ];
      public lineChartData3: Array<any> = [
          0, 0, 0, 0, 0, 0, 0, 0,0 ,0
          ];

          public lineChartData4: Array<any> = [
            0, 0, 0, 0, 0, 0, 0, 0,0,0
            ];
          public lineChartData5: Array<any> = [
              0, 0, 0, 0, 0, 0, 0, 0,0 ,0
              ];

              public lineChartData6: Array<any> = [
                0, 0, 0, 0, 0, 0, 0, 0,0,0
                ];
              public lineChartData7: Array<any> = [
                  0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                  ];
                  public lineChartData8: Array<any> = [
                    0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                    ];
                  public lineChartData9: Array<any> = [
                    0, 0, 0, 0, 0, 0, 0, 0,0,0
                    ];
                  public lineChartData10: Array<any> = [
                      0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                      ];
                      public lineChartData11: Array<any> = [
                        0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                        ];
                      public lineChartData12: Array<any> = [
                        0, 0, 0, 0, 0, 0, 0, 0,0,0
                        ];
                      public lineChartData13: Array<any> = [
                          0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                          ];

                          public lineChartData14: Array<any> = [
                            0, 0, 0, 0, 0, 0, 0, 0,0,0
                            ];
                          public lineChartData15: Array<any> = [
                              0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                              ];

                              public lineChartData16: Array<any> = [
                                0, 0, 0, 0, 0, 0, 0, 0,0,0
                                ];
                              public lineChartData17: Array<any> = [
                                  0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                                  ];

                              public lineChartData18: Array<any> = [
                                0, 0, 0, 0, 0, 0, 0, 0,0,0
                                ];
                              public lineChartData19: Array<any> = [
                                  0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                                  ];
                                  public lineChartData20: Array<any> = [
                                    0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                                    ];

                                  public lineChartData21: Array<any> = [
                                    0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                                    ];
                                    public lineChartData22: Array<any> = [
                                      0, 0, 0, 0, 0, 0, 0, 0,0,0
                                      ];
                                    public lineChartData23: Array<any> = [
                                        0, 0, 0, 0, 0, 0, 0, 0,0 ,0
                                        ];



    public lineChartLabels: Array<any> = ['1', '2', '3', '4', '4', '5', '6', '7', '8', '9'];
    public lineChartLabels1: Array<any> = ['1', '2', '3', '4', '4', '5', '6', '7', '8', '9'];
    public lineChartLabels2: Array<any> = ['1', '2', '3', '4', '4', '5', '6', '7', '8', '9'];
    public lineChartLabels3: Array<any> = ['1', '2', '3', '4', '4', '5', '6', '7', '8', '9'];


    public labelMFL: Array<any> = [
        { data: [] = this.lineChartData,
          label: ''
        },
        {  data: [] =  this.lineChartData1,
          label: ''
        },
        {  data: [] =  this.lineChartData2,
          label: ''
        },
        {  data: [] =  this.lineChartData3,
          label: ''
        },
        {  data: [] =  this.lineChartData4,
          label: ''
        },
        {  data: [] =  this.lineChartData5,
          label: ''
        },

    ];
    public labelMFL1: Array<any> = [
      {  data: [] =  this.lineChartData6,
        label: ''
      },
      {  data: [] =  this.lineChartData7,
        label: ''
      },
      {  data: [] =  this.lineChartData8,
        label: ''
      },
      {  data: [] =  this.lineChartData9,
        label: ''
      },
      {  data: [] =  this.lineChartData10,
        label: ''
      },
      {  data: [] =  this.lineChartData11,
        label: ''
      },

  ];
  public labelMFL2: Array<any> = [
    {  data: [] =  this.lineChartData12,
      label: ''
    },
    {  data: [] =  this.lineChartData13,
      label: ''
    },
    {  data: [] =  this.lineChartData14,
      label: ''
    },
    {  data: [] =  this.lineChartData16,
      label: ''
    },
    {  data: [] =  this.lineChartData16,
      label: ''
    },
    {  data: [] =  this.lineChartData17,
      label: ''
    },

];
public labelMFL3: Array<any> = [
  {  data: [] =  this.lineChartData18,
    label: ''
  },
  {  data: [] =  this.lineChartData19,
    label: ''
  },
  {  data: [] =  this.lineChartData20,
    label: ''
  },
  {  data: [] =  this.lineChartData21,
    label: ''
  },
  {  data: [] =  this.lineChartData22,
    label: ''
  },
  {  data: [] =  this.lineChartData23,
    label: ''
  },

];
selectedQuantityp = 'SKF BNG'
onOptionsSelectedp(selectedQuantity){


}
    onOptionsSelected(value){

      this.labelMFL = [
        { data: [] = this.lineChartData,
          label: ''
        },
        {  data: [] =  this.lineChartData1,
          label: ''
        },
        {  data: [] =  this.lineChartData2,
          label: ''
        },
        {  data: [] =  this.lineChartData3,
          label: ''
        },
        {  data: [] =  this.lineChartData4,
          label: ''
        },
        {  data: [] =  this.lineChartData5,
          label: ''
        },

    ];
    this.labelMFL1 = [
      {  data: [] =  this.lineChartData6,
        label: ''
      },
      {  data: [] =  this.lineChartData7,
        label: ''
      },
      {  data: [] =  this.lineChartData8,
        label: ''
      },
      {  data: [] =  this.lineChartData9,
        label: ''
      },
      {  data: [] =  this.lineChartData10,
        label: ''
      },
      {  data: [] =  this.lineChartData11,
        label: ''
      },

  ];

  this.labelMFL2 = [
    {  data: [] =  this.lineChartData12,
      label: ''
    },
    {  data: [] =  this.lineChartData13,
      label: ''
    },
    {  data: [] =  this.lineChartData14,
      label: ''
    },
    {  data: [] =  this.lineChartData15,
      label: ''
    },
    {  data: [] =  this.lineChartData16,
      label: ''
    },
    {  data: [] =  this.lineChartData17,
      label: ''
    },


];

this.labelMFL3 = [
  {  data: [] =  this.lineChartData18,
    label: ''
  },
  {  data: [] =  this.lineChartData19,
    label: ''
  },
  {  data: [] =  this.lineChartData20,
    label: ''
  },
  {  data: [] =  this.lineChartData21,
    label: ''
  },
  {  data: [] =  this.lineChartData22,
    label: ''
  },
  {  data: [] =  this.lineChartData23,
    label: ''}

];



      console.log("the selected value is " + this.selectedQuantity);

    }

    onOptionsSelecteds(value){

//       this.labelMFL = [
//         { data: this.lineChartData,
//           label: ''
//         },
//         { data: this.lineChartData1,
//           label: ''
//         },

//     ];
//     this.labelMFL1 = [
//       { data: this.lineChartData,
//         label: ''
//       },
//       { data: this.lineChartData1,
//         label: ''
//       },

//   ];

//   this.labelMFL2 = [
//     { data: this.lineChartData,
//       label: ''
//     },
//     { data: this.lineChartData1,
//       label: ''
//     },

// ];

// this.labelMFL3 = [
//   { data: this.lineChartData,
//     label: ''
//   },
//   { data: this.lineChartData1,
//     label: ''
//   },

// ];


      this.chart.chart.clear();
      this.chart1.chart.clear();
      this.chart2.chart.clear();
      this.chart3.chart.clear();
      this.chart.chart.clear();
      setTimeout(() => {

        // this.values1 = ''
        // this.tagvalues1 = ''
        // this.values2 = ''
        // this.tagvalues2 = ''
        // this.values3 = ''
        // this.tagvalues4 = ''
        // this.values4 = ''
        // this.tagvalues4 = ''
        // this.values5 = ''
        // this.tagvalues5 = ''
        // this.values6 = ''
        // this.tagvalues6 = ''
        // this.values7 = ''
        // this.tagvalues7 = ''
        // this.values8 = ''
        // this.tagvalues8 = ''
        console.log('clear chart ********************************');
      this.chart.chart.clear();
      this.chart1.chart.clear();
      this.chart2.chart.clear();
      this.chart3.chart.clear();


      this.lineChartData = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData1 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData2 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData3 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData4 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData5 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL = [
        {  data: [] =  this.lineChartData,
          label: this.tagvalues1
        },
        {  data: [] =  this.lineChartData1,
          label: this.tagvalues2
        },
        {  data: [] =  this.lineChartData2,
          label: this.tagvalues3
        },
        {  data: [] =  this.lineChartData3,
          label: this.tagvalues4
        },
        {  data: [] =  this.lineChartData4,
          label: this.tagvalues5
        },
        {  data: [] =  this.lineChartData5,
          label: this.tagvalues6
        },


    ];
    this.lineChartData6 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData7 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData8 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData9 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData10 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData11 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL1 = [


    {  data: [] =  this.lineChartData6,
      label: this.tagvalues7
    },
    {  data: [] =  this.lineChartData7,
      label: this.tagvalues8
    },
    {  data: [] =  this.lineChartData8,
      label: this.tagvalues9
    },
    {  data: [] =  this.lineChartData9,
      label: this.tagvalues10
    },
    {  data: [] =  this.lineChartData10,
      label: this.tagvalues11
    },
    {  data: [] =  this.lineChartData11,
      label: this.tagvalues12
    },
  ];
      this.lineChartData12 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData13 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData14 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData15 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData16 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData17 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL2 = [
        {  data: [] =  this.lineChartData12,
          label: this.tagvalues13
        },
        {  data: [] =  this.lineChartData13,
          label: this.tagvalues14
        },
        {  data: [] =  this.lineChartData14,
          label: this.tagvalues15
        },
        {  data: [] =  this.lineChartData15,
          label: this.tagvalues16
        },
        {  data: [] =  this.lineChartData16,
          label: this.tagvalues17
        },
        {  data: [] =  this.lineChartData17,
          label: this.tagvalues18
        },

];
      this.lineChartData18 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData19 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData20 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData21 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData22 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData23 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]

      this.labelMFL3 = [
  {  data: [] =  this.lineChartData18,
    label: this.tagvalues19
  },
  {  data: [] =  this.lineChartData19,
    label: this.tagvalues20
  },
  {  data: [] =  this.lineChartData20,
    label: this.tagvalues21
  },
  {  data: [] =  this.lineChartData21,
    label: this.tagvalues22
  },
  {  data: [] =  this.lineChartData22,
    label: this.tagvalues23
  },
  {  data: [] =  this.lineChartData23,
    label: this.tagvalues24
  },

];
      }, 5000);

      this.lineChartData = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData1 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData2 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData3 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData4 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData5 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL = [
        {  data: [] =  this.lineChartData,
          label: this.tagvalues1
        },
        {  data: [] =  this.lineChartData1,
          label: this.tagvalues2
        },
        {  data: [] =  this.lineChartData2,
          label: this.tagvalues3
        },
        {  data: [] =  this.lineChartData3,
          label: this.tagvalues4
        },
        {  data: [] =  this.lineChartData4,
          label: this.tagvalues5
        },
        {  data: [] =  this.lineChartData5,
          label: this.tagvalues6
        },


    ];
    this.lineChartData6 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData7 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData8 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData9 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData10 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
    this.lineChartData11 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL1 = [


    {  data: [] =  this.lineChartData6,
      label: this.tagvalues7
    },
    {  data: [] =  this.lineChartData7,
      label: this.tagvalues8
    },
    {  data: [] =  this.lineChartData8,
      label: this.tagvalues9
    },
    {  data: [] =  this.lineChartData9,
      label: this.tagvalues10
    },
    {  data: [] =  this.lineChartData10,
      label: this.tagvalues11
    },
    {  data: [] =  this.lineChartData11,
      label: this.tagvalues12
    },
  ];
      this.lineChartData12 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData13 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData14 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData15 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData16 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData17 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.labelMFL2 = [
        {  data: [] =  this.lineChartData12,
          label: this.tagvalues13
        },
        {  data: [] =  this.lineChartData13,
          label: this.tagvalues14
        },
        {  data: [] =  this.lineChartData14,
          label: this.tagvalues15
        },
        {  data: [] =  this.lineChartData15,
          label: this.tagvalues16
        },
        {  data: [] =  this.lineChartData16,
          label: this.tagvalues17
        },
        {  data: [] =  this.lineChartData17,
          label: this.tagvalues18
        },

];
      this.lineChartData18 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData19 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData20 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData21 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData22 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]
      this.lineChartData23 = [0, 0, 0, 0, 0, 0, 0, 0,0,0]

      this.labelMFL3 = [
  {  data: [] =  this.lineChartData18,
    label: this.tagvalues19
  },
  {  data: [] =  this.lineChartData19,
    label: this.tagvalues20
  },
  {  data: [] =  this.lineChartData20,
    label: this.tagvalues21
  },
  {  data: [] =  this.lineChartData21,
    label: this.tagvalues22
  },
  {  data: [] =  this.lineChartData22,
    label: this.tagvalues23
  },
  {  data: [] =  this.lineChartData23,
    label: this.tagvalues24
  },

];
setTimeout(() => {

  this.chart.chart.update();

  console.log('updat chart ********************************');

  }, 7000);

      this.chart.chart.update();
      this.chart1.chart.update();
      this.chart2.chart.update();
      this.chart3.chart.update();

      // console.log("the selected value is machine name " + this.selectedQuantitys);
      // this.chirt1(this.selectedQuantitys)


    }

    public lineChartOptions: any = {

      responsive: true, legend: {
        position: 'right',
        align: 'start',
    },
      scales : {

      yAxes: [{
         ticks: {
          //  steps : 25,
          //  stepValue : 15,
          //  max : 40,
            min : 0,
          }
      }]
    }
    };
    public lineChartColors: Array<any> = [
      { // grey
        backgroundColor: 'rgba(102,159,177,0.2)',
        borderColor: 'rgba(102,159,177,1)',
        pointBackgroundColor: 'rgba(102,159,177,1)',
        pointBorderColor: '#66fff',
        pointHoverBackgroundColor: '#66fff',
        pointHoverBorderColor: 'rgba(102,159,177,0.8)'
      }
    ];

    public lineChartLegend = true;

    public lineChartType = 'line';



    // events
    public chartClicked(e: any): void {
      console.log(e);
    }

    public chartHovered(e: any): void {
      console.log(e);
    }
  ngOnInit(): void {


this.chirt1()



  }


 chirt1(){

  setInterval(() => {
    this.http.get<any>('http://122.166.167.113:8085/linecharttags/'+this.selectedQuantity).subscribe(data => {
      this.tasklist = data.filter(
        task => task.chartno === 1),this.tasklist1 = data.filter(
          task => task.chartno === 2),this.tasklist2 = data.filter(
            task => task.chartno === 3),this.tasklist3 = data.filter(
              task => task.chartno === 4)
      if (this.tasklist[1] == null){
          console.log('if get request data 1', this.tasklist);
        }

        else{
          console.log('else get request data 1', this.tasklist);
        }

    });
    console.log('labelMFL,labelMFL', this.labelMFL);

    const _lineChartData = this.lineChartData;
    const _lineChartLabels = this.lineChartLabels;

    _lineChartData.push(this.tasklist[0].realtimeval);
    this.values1 = parseFloat(this.tasklist[0].realtimeval).toFixed(2);
    this.tagvalues1 = (this.tasklist[0].description);
    const newlable1 = (this.tasklist[0].timestamp).toString().split(" ");
    console.log('newlable1',newlable1[4]);

    _lineChartLabels.push(newlable1[4]);
    this.label++;
    console.log('tagvalues1======================================', this.tagvalues1);

    this.lineChartData.splice(0, 1);
    this.lineChartLabels.splice(0, 1);

    this.lineChartData = _lineChartData;
    this.lineChartLabels = _lineChartLabels;

    if (this.tasklist[1] == null){
      console.log('get request data 1', this.tasklist[0]['realtimeval'])
    }
    else{
      const _lineChartData1 = this.lineChartData1;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData1.push(this.tasklist[1].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values2 = parseFloat(this.tasklist[1].realtimeval).toFixed(2)
      this.tagvalues2 = (this.tasklist[1].description);
      this.lineChartData1.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData1 = _lineChartData1;
      // this.lineChartLabels1 = _lineChartLabels1;
    }
    if (this.tasklist[2] == null){
      console.log('get request data 1', this.tasklist[0]['realtimeval'])
    }
    else{
      const _lineChartData2 = this.lineChartData2;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData2.push(this.tasklist[2].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values3 = parseFloat(this.tasklist[2].realtimeval).toFixed(2)
      this.tagvalues3 = (this.tasklist[2].description);
      this.lineChartData2.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData2 = _lineChartData2;
      // this.lineChartLabels1 = _lineChartLabels1;
    }

    console.log("linechart data", this.lineChartData1)

    if (this.tasklist[3] == null){
      console.log('get request data 1', this.tasklist[0]['realtimeval'])
    }
    else{
      const _lineChartData3 = this.lineChartData3;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData3.push(this.tasklist[3].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values4 = parseFloat(this.tasklist[3].realtimeval).toFixed(2)
      this.tagvalues4 = (this.tasklist[3].description);
      this.lineChartData3.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData3 = _lineChartData3;
      // this.lineChartLabels1 = _lineChartLabels1;
    }

    console.log("linechart data", this.lineChartData1)

    if (this.tasklist[4] == null){
      console.log('get request data 1', this.tasklist[0]['realtimeval'])
    }
    else{
      const _lineChartData4 = this.lineChartData4;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData4.push(this.tasklist[4].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values5 = parseFloat(this.tasklist[4].realtimeval).toFixed(2)
      this.tagvalues5 = (this.tasklist[4].description);
      this.lineChartData4.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData4 = _lineChartData4;
      // this.lineChartLabels1 = _lineChartLabels1;
    }

    if (this.tasklist[5] == null){
      console.log('get request data 1', this.tasklist[0]['realtimeval'])
    }
    else{
      const _lineChartData5 = this.lineChartData5;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData5.push(this.tasklist[5].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values6 = parseFloat(this.tasklist[5].realtimeval).toFixed(2)
      this.tagvalues6 = (this.tasklist[5].description);
      this.lineChartData5.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData5 = _lineChartData5;
      // this.lineChartLabels1 = _lineChartLabels1;
    }

      const _lineChartData6 = this.lineChartData6;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData6.push(this.tasklist1[0].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values7 = parseFloat(this.tasklist1[0].realtimeval).toFixed(2)
      this.tagvalues7 = (this.tasklist1[0].description);
      this.lineChartData6.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData6 = _lineChartData6;

      const _lineChartData7 = this.lineChartData7;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData7.push(this.tasklist1[1].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values8 = parseFloat(this.tasklist1[1].realtimeval).toFixed(2)
      this.tagvalues8 = (this.tasklist1[1].description);
      this.lineChartData7.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData7 = _lineChartData7;

      const _lineChartData8 = this.lineChartData8;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData8.push(this.tasklist1[2].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values9 = parseFloat(this.tasklist1[2].realtimeval).toFixed(2)
      this.tagvalues9 = (this.tasklist1[2].description);
      this.lineChartData8.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData8 = _lineChartData8;

      const _lineChartData9 = this.lineChartData9;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData9.push(this.tasklist1[3].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values10 = parseFloat(this.tasklist1[3].realtimeval).toFixed(2)
      this.tagvalues10 = (this.tasklist1[3].description);
      this.lineChartData9.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData9 = _lineChartData9;

      const _lineChartData10 = this.lineChartData10;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData10.push(this.tasklist1[4].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values11 = parseFloat(this.tasklist1[4].realtimeval).toFixed(2)
      this.tagvalues11 = (this.tasklist1[4].description);
      this.lineChartData10.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData10 = _lineChartData10;

      const _lineChartData11 = this.lineChartData11;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData11.push(this.tasklist1[5].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values12 = parseFloat(this.tasklist1[5].realtimeval).toFixed(2)
      this.tagvalues12 = (this.tasklist1[5].description);
      this.lineChartData11.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData11 = _lineChartData11;






      const _lineChartData12 = this.lineChartData12;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData12.push(this.tasklist2[0].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values13 = parseFloat(this.tasklist2[0].realtimeval).toFixed(2)
      this.tagvalues13 = (this.tasklist2[0].description);
      this.lineChartData12.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData12 = _lineChartData12;

      const _lineChartData13 = this.lineChartData13;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData13.push(this.tasklist2[1].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values14 = parseFloat(this.tasklist2[1].realtimeval).toFixed(2)
      this.tagvalues14 = (this.tasklist2[1].description);
      this.lineChartData13.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData13 = _lineChartData13;

      const _lineChartData14 = this.lineChartData14;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData14.push(this.tasklist2[2].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values15 = parseFloat(this.tasklist2[2].realtimeval).toFixed(2)
      this.tagvalues15 = (this.tasklist2[2].description);
      this.lineChartData14.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData14 = _lineChartData14;

      const _lineChartData15 = this.lineChartData15;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData15.push(this.tasklist2[3].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values16 = parseFloat(this.tasklist2[3].realtimeval).toFixed(2)
      this.tagvalues16 = (this.tasklist2[3].description);
      this.lineChartData15.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData15 = _lineChartData15;

      if (this.selectedQuantity == 'CHANNEL-5'){
      const _lineChartData16 = this.lineChartData16;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData16.push(this.tasklist2[4].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values17 = parseFloat(this.tasklist2[4].realtimeval).toFixed(2)
      this.tagvalues17 = (this.tasklist2[4].description);
      this.lineChartData16.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData16 = _lineChartData16;

      const _lineChartData17 = this.lineChartData17;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData17.push(this.tasklist2[5].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values18 = parseFloat(this.tasklist2[5].realtimeval).toFixed(2)
      this.tagvalues18 = (this.tasklist2[5].description);
      this.lineChartData17.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData17 = _lineChartData17;
      }

      else{
        this.lineChartData17 =[]
        this.values18 = ''
        this.tagvalues18 = ''
        this.lineChartData16 =[]
        this.values17 = ''
        this.tagvalues17 = ''
      }

      const _lineChartData18 = this.lineChartData18;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData18.push(this.tasklist3[0].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values19 = parseFloat(this.tasklist3[0].realtimeval).toFixed(2)
      this.tagvalues19 = (this.tasklist3[0].description);
      this.lineChartData18.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData18 = _lineChartData18;

      const _lineChartData19 = this.lineChartData19;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData19.push(this.tasklist3[1].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values20 = parseFloat(this.tasklist3[1].realtimeval).toFixed(2)
      this.tagvalues20 = (this.tasklist3[1].description);
      this.lineChartData19.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData19 = _lineChartData19;

      const _lineChartData20 = this.lineChartData20;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData20.push(this.tasklist3[2].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values21 = parseFloat(this.tasklist3[2].realtimeval).toFixed(2)
      this.tagvalues21 = (this.tasklist3[2].description);
      this.lineChartData20.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData20 = _lineChartData20;

      const _lineChartData21 = this.lineChartData21;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData21.push(this.tasklist3[3].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values22 = parseFloat(this.tasklist3[3].realtimeval).toFixed(2)
      this.tagvalues22 = (this.tasklist3[3].description);
      this.lineChartData21.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData21 = _lineChartData21;

      const _lineChartData22 = this.lineChartData22;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData22.push(this.tasklist3[4].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values23 = parseFloat(this.tasklist3[4].realtimeval).toFixed(2)
      this.tagvalues23 = (this.tasklist3[4].description);
      this.lineChartData22.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData22 = _lineChartData22;

      const _lineChartData23 = this.lineChartData23;
      // const _lineChartLabels1 = this.lineChartLabels1;

      _lineChartData23.push(this.tasklist3[5].realtimeval);
      // _lineChartLabels1.push(this.tasklist[1].timestamp);
      this.label++;
      this.values24 = parseFloat(this.tasklist3[5].realtimeval).toFixed(2)
      this.tagvalues24 = (this.tasklist3[5].description);
      this.lineChartData23.splice(0, 1);
      // this.lineChartLabels1.splice(0, 1);

      this.lineChartData23 = _lineChartData23;




    this.chart.chart.update();
    this.chart1.chart.update();
    this.chart2.chart.update();
    this.chart3.chart.update();
  }, 2000);
  }



}
