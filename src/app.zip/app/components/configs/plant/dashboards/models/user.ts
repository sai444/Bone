export class User {
  public id: string;
  public firstName: string;
  public lastName: string;
}