import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-color',
  templateUrl: './state-color.component.html',
  styleUrls: ['./state-color.component.scss']
})
export class StateColorComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
