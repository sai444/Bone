import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tag-n-pills',
  templateUrl: './tag-n-pills.component.html',
  styleUrls: ['./tag-n-pills.component.scss']
})
export class TagNPillsComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
