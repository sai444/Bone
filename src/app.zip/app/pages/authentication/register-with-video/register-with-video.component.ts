import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-with-video',
  templateUrl: './register-with-video.component.html',
  styleUrls: ['./register-with-video.component.scss']
})
export class RegisterWithVideoComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
